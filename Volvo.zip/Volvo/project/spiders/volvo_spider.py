from scrapy import Spider
from project.items import *

class VolvoSpider(Spider):
    name = "volvo"
    allow_domain = ['www.century-volvo.com']
    start_urls = [
        'https://www.century-volvo.com/new-inventory/index.htm'
    ]

    handle_httpstatus_list = [503]

    def parse(self, response):
        if response.status == 503:
            yield scrapy.FormRequest(url = response.url,callback = self.parse,dont_filter=True)
        else:
            product = response.xpath('//div[@class="hproduct auto volvo"]')

            for p in product:
                item = ProjectItem()
                item['title'] = p.xpath('.//h3//a[@class="url"]/text()').get()
                item['engine'] = p.xpath('//*[contains(text(),"Engine")]/./following-sibling::dd[2]/text()').get()
                # item['milage'] = p.xpath('')
                item['stock_num'] = p.xpath('//*[contains(text(),"Stock #")]/./following-sibling::dd/text()').get()
                # item['vin'] = p.xpath('')
                item['price'] = p.xpath('.//span[@class="value"]/text()').get()
                # item['year'] = p.xpath('')
                item['site_domain'] ="https://www.century-volvo.com/"+p.xpath('.//a[@class="url"]/@href').get()
                item['additional_info'] = p.xpath('//*[contains(text(),"MPG Range")]/./following-sibling::dd[1]/text()').get()

                yield item

            next_page = response.xpath('//a[@rel="next"]/@href').extract_first()
            if next_page:
                g = 'https://www.century-volvo.com/new-inventory/index.htm'+next_page
                yield scrapy.Request(url=g, callback=self.parse)

from scrapy.cmdline import execute
execute('scrapy crawl volvo'.split())



